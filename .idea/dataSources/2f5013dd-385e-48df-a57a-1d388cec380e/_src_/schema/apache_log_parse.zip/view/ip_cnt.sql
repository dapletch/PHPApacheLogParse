CREATE VIEW `ip_cnt` AS
  SELECT
    `apache_log_parse`.`log_data`.`ip_address`        AS `ip_address`,
    count(`apache_log_parse`.`log_data`.`ip_address`) AS `tot_ip_cnt`
  FROM `apache_log_parse`.`log_data`
  GROUP BY 1
  ORDER BY 1