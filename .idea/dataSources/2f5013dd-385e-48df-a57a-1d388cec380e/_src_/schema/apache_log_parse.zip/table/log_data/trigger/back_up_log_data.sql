CREATE TRIGGER `back_up_log_data`
AFTER INSERT ON `log_data`
FOR EACH ROW
  insert into log_data_old (ip_address, remote_user, time_accessed, request, stat_cd, bytes_sent, time_entered)
    values (NEW.ip_address, NEW.remote_user, NEW.time_accessed, NEW.request, NEW.stat_cd, NEW.bytes_sent, NEW.time_entered)